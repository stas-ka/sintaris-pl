# todos

1. Documents for SI accounting prepare and send
2. Tax declaration 2025